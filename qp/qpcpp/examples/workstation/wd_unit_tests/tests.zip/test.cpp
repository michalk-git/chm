#include "pch.h"
#include "watchdog.h"
#include <chrono>


#define TIME_INTERVAL 10

void wait(int seconds) {
	std::chrono::system_clock::time_point last = std::chrono::system_clock::now();
	std::chrono::system_clock::time_point curr = last;
	std::chrono::milliseconds wait_time = std::chrono::seconds(seconds) + std::chrono::milliseconds(100);
	//std::cout << "wait " << wait_time.count() << std::endl;
	while ((curr - last) <= wait_time) {
		curr = std::chrono::system_clock::now();
	}

}

TEST(WatchDogTests,initialization) {
	WatchDog& wd = WatchDog::getInstance();
	wd.start();
    EXPECT_EQ(wd.GetCounter().count(), Core_Health::CHMConfig_t::T_WATCHDOG_RESET_SEC);                
    //std::cout << "counter is " << wd.GetCounter().count() << std::endl;
    wd.stop();
 
}

TEST(WatchDogTests, CountDownByTIME_INTERVAL) {
	WatchDog& wd = WatchDog::getInstance();
	wd.start();
	//std::cout << "counter is " << wd.GetCounter().count() << std::endl;
	wait(TIME_INTERVAL);
	EXPECT_EQ(wd.GetCounter().count(), (Core_Health::CHMConfig_t::T_WATCHDOG_RESET_SEC - TIME_INTERVAL));
	//std::cout << "counter is " << wd.GetCounter().count() << std::endl;
	wd.stop();
}

TEST(WatchDogTests, CountDownByT_WATCHDOG_RESET_SEC) {
	WatchDog& wd = WatchDog::getInstance();
	wd.start();
	//std::cout << "counter is " << wd.GetCounter().count() << std::endl;
	wait(Core_Health::CHMConfig_t::T_WATCHDOG_RESET_SEC);
	EXPECT_EQ(wd.GetCounter().count(), 0);
	//std::cout << "counter is " << wd.GetCounter().count() << std::endl;
	wd.stop();
}

TEST(WatchDogTests, Kick) {
	WatchDog& wd = WatchDog::getInstance();
	wd.start();
	//std::cout << "counter is " << wd.GetCounter().count() << std::endl;
	wait(TIME_INTERVAL);
	wd.kick();
	EXPECT_EQ(wd.GetCounter().count(), Core_Health::CHMConfig_t::T_WATCHDOG_RESET_SEC);
	//std::cout << "counter is " << wd.GetCounter().count() << std::endl;
	wd.stop();
}

TEST(WatchDogTests, ResetCounter) {
	
	WatchDog& wd = WatchDog::getInstance();
	wd.SetResetInterval(TIME_INTERVAL);
	wd.start();
	//std::cout << "counter is " << wd.GetCounter().count() << std::endl;
	EXPECT_EQ(wd.GetCounter().count(), TIME_INTERVAL);
	//std::cout << "counter is " << wd.GetCounter().count() << std::endl;
	wd.stop();
}

TEST(WatchDogTests, Decrement) {

	WatchDog& wd = WatchDog::getInstance();
	wd.start();
	wd.Decrement(std::chrono::seconds(TIME_INTERVAL));
	//std::cout << "counter is " << wd.GetCounter().count() << std::endl;
	EXPECT_EQ(wd.GetCounter().count(), (Core_Health::CHMConfig_t::T_WATCHDOG_RESET_SEC - TIME_INTERVAL));
	//std::cout << "counter is " << wd.GetCounter().count() << std::endl;
	wd.stop();
}